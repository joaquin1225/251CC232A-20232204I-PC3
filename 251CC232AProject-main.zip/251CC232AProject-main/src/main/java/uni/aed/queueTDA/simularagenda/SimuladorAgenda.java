package uni.aed.queueTDA.simularagenda;

import java.util.Random;
import uni.aed.queueTDA.*;
import uni.aed.tda.ArrayListTDA.ArrayListTDA;

public class SimuladorAgenda {
    private PriorityQueueTDA<Trabajo> colaPrioridad;
    private ArrayListTDA<Trabajo> ejecutando;
    private ArrayListTDA<Trabajo> completados;
    private int tiempoActual;
    private int capacidadConcurrente;
    private Random random;

    public SimuladorAgenda(int capacidadConcurrente) {
        this.capacidadConcurrente = capacidadConcurrente;
        this.random = new Random();
        this.colaPrioridad = new PriorityQueueTDA<>();
        this.ejecutando = new ArrayListTDA<>(capacidadConcurrente);
        this.completados = new ArrayListTDA<>();
    }

    public void generarTrabajo(int id) {
        int prioridad = 1 + random.nextInt(5);
        int duracion = 1 + random.nextInt(10);
        Trabajo t = new Trabajo(id, prioridad, duracion, tiempoActual);
        colaPrioridad.enqueue(t);
    }

    // Simula M minutos
    public void simular(int minutos) throws QueueEmptyExceptionTDA {
        //en el minuto 0 generamos una cantidad de trabajos igual a la capacidad de ejecuccion concurrente mas uno
        tiempoActual = 0;
        int id = 1;
        for(int i=id; i<=capacidadConcurrente+1; i++) {
            generarTrabajo(i);
        }
        while (ejecutando.size() < capacidadConcurrente && !colaPrioridad.isEmpty()) {
            Trabajo nuevo = colaPrioridad.dequeue();
            nuevo.setTiempoInicio(tiempoActual);
            ejecutando.add(nuevo);
            nuevo.setTiempoEspera(nuevo.getTiempoInicio() - nuevo.getTiempoLlegada());
        }

        //generaremos un trabajo cada que pasa un minuto
        while (tiempoActual < minutos) {
            generarTrabajo(id++);

            //avanzamos un minuto para todos los trabajos en ejecución
            for (int i = 0; i < ejecutando.size(); i++) {
                Trabajo t = ejecutando.get(i);
                t = new Trabajo(t.getId(), t.getPrioridad(), t.getDuracion() - 1, t.getTiempoLlegada());
                t.setTiempoInicio(tiempoActual);

                if (t.getDuracion() <= 0) {
                    completados.add(t);
                    ejecutando.delete(i);
                    i--;
                }
            }

            //asignamos nuevos trabajos si hay espacio
            while (ejecutando.size() < capacidadConcurrente && !colaPrioridad.isEmpty()) {
                Trabajo nuevo = colaPrioridad.dequeue();
                nuevo.setTiempoInicio(tiempoActual);
                ejecutando.add(nuevo);
                nuevo.setTiempoEspera(nuevo.getTiempoInicio() - nuevo.getTiempoLlegada());
            }
            tiempoActual++;
        }
    }

    public ArrayListTDA<Trabajo> getCompletados() {
        return completados;
    }

    public void resetear() {
        colaPrioridad = new PriorityQueueTDA<>();
        ejecutando.clear();
        completados.clear();
        tiempoActual = 0;
    }

    public PriorityQueueTDA<Trabajo> getColaPrioridad() {
        return colaPrioridad;
    }
}
