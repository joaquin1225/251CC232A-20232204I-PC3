package uni.aed.queueTDA.simularagenda;

public class Trabajo implements Comparable<Trabajo> {
    private int id;
    private int prioridad;
    private int duracion;
    private int tiempoLlegada;
    private int tiempoInicio;
    private int tiempoEspera;

    public Trabajo(int id, int prioridad, int duracion, int tiempoLlegada) {
        this.id = id;
        this.prioridad = prioridad;
        this.duracion = duracion;
        this.tiempoLlegada = tiempoLlegada;
        this.tiempoInicio = -1;
    }

    public int getId() {
        return id;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public int getTiempoLlegada() {
        return tiempoLlegada;
    }

    public void setTiempoLlegada(int tiempoLlegada) {
        this.tiempoLlegada = tiempoLlegada;
    }

    public int getTiempoInicio() {
        return tiempoInicio;
    }

    public void setTiempoInicio(int tiempoInicio) {
        this.tiempoInicio = tiempoInicio;
    }

    public int getTiempoEspera() {
        return tiempoEspera;
    }

    public void setTiempoEspera(int tiempoEspera) {
        this.tiempoEspera = tiempoEspera;
    }

    @Override
    public String toString() {
        return "Trabajo:" + id + " [prioridad=" + prioridad + ", Tiempo de ejecucion =" + duracion + " min, Tiempo de llegada =" + tiempoLlegada + ", Tiempo de inicio de ejecucion=" + tiempoInicio + "]";
    }

    @Override
    public int compareTo(Trabajo o) {
        return this.prioridad - o.prioridad;
    }
}

