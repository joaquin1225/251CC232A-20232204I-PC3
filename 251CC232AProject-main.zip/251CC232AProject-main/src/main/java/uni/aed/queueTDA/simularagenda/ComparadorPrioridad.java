package uni.aed.queueTDA.simularagenda;

import java.util.Comparator;

public class ComparadorPrioridad implements Comparator<Trabajo> {
    @Override
    public int compare(Trabajo o1, Trabajo o2) {
        return Integer.compare(o1.getPrioridad(), o2.getPrioridad());
    }
}
