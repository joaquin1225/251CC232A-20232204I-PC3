package uni.aed.queueTDA.simularagenda;

import java.util.Scanner;
import uni.aed.queueTDA.*;

public class SimuladorAgendaMain {
    public static SimuladorAgenda simulador;

    public static void main(String[] args) throws QueueEmptyExceptionTDA {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Menú Agenda de Trabajo ---");
            System.out.println("1. Cargar Agenda de Trabajo");
            System.out.println("2. Obtener tiempo de espera promedio");
            System.out.println("3. Obtener tiempo de espera máximo por prioridad");
            System.out.println("4. Eliminar Agenda de Trabajo");
            System.out.println("5. Visualizar Agenda de Trabajo");
            System.out.println("0. Salir");
            System.out.print("Opción: ");
            int op = sc.nextInt();

            switch (op) {
                case 1:
                    System.out.print("Minutos a simular: ");
                    int m = sc.nextInt();
                    System.out.println("Numero de trabajos ejecutados concurrentemente");
                    int n = sc.nextInt();
                    simulador = new SimuladorAgenda(n);
                    simulador.simular(m);
                    System.out.println("Simulación completada.");
                    break;
                case 2:
                    int tiempoTotal=0;
                    for(int i=0; i<simulador.getCompletados().size(); i++) {
                        tiempoTotal = tiempoTotal+(simulador.getCompletados().get(i).getTiempoInicio()-simulador.getCompletados().get(i).getTiempoLlegada());
                    }
                    double promedio=tiempoTotal/(double)simulador.getCompletados().size();
                    System.out.println("Tiempo de espera promedio: " + promedio + " minutos");
                    break;
                case 3:
                    int[] maximos = new int[5];
                    for (int p = 0; p < 5; p++) {
                        int a=0;
                        for(int i=0; i<simulador.getCompletados().size(); i++) {
                            if(simulador.getCompletados().get(i).getTiempoEspera()>a){
                                a=simulador.getCompletados().get(i).getTiempoEspera();
                            }
                        }
                        maximos[p]=a;
                    }
                    for (int p = 0; p < 5; p++) {
                        System.out.println("Tiempo de espera maximo de prioridad " + (p+1) +" es: "+maximos[p]+" minutos");
                    }
                    break;
                case 4:
                    simulador.resetear();
                    System.out.println("Agenda eliminada.");
                    break;
                case 5:
                    System.out.println("----AGENDA DE TRABAJOS----");
                    System.out.println("Trabajos completados:");
                    for(int i=0; i<simulador.getCompletados().size(); i++) {
                        System.out.println(simulador.getCompletados().get(i).toString());
                    }
                    System.out.println("Trabajos retenidos en cola:");
                    for(int i=0; i<simulador.getColaPrioridad().size(); i++) {
                        System.out.println(simulador.getColaPrioridad().dequeue().toString());
                    }
                    break;
                case 0:
                    System.out.println("Saliendo...");
                    return;
                default:
                    System.out.println("Opción inválida");
            }
        }
    }
}



